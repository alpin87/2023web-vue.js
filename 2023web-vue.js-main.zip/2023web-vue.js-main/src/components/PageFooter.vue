<template>
    <footer>
    <hr>
    <h1>푸터</h1>
    </footer>
</template>

<script>
</script>

<style>

</style>
